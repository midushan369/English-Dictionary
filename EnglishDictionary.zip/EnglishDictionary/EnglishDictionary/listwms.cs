﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnglishDictionary
{
    //creating a static class there for all the progarm as on class
    static class listwms
    {
        //creating a static class there for all the progarm as on List
        public static List<wordmenset> Dlist = new List<wordmenset>();
    }
}
